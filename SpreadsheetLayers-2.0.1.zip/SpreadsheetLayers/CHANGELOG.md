## Changelog

**Version 1.0.1**

* Add sheet name in default layer name.
* Handle non ascii characters in sheet names.
* Dynamically load .ui files.
* Handle non ascii characters in file paths.
* Add sheet name in .vrt filename to support multiple worksheets.
* Add russian translation file.

**Version 1.0**

* Add changelog file.
* Add checkbox for end of file detection.
* Force encoding to UTF-8 before adding layer to layer tree.
* Fix column format selectors line position.
