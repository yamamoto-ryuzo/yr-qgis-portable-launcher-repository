# ZoomView

ZoomView is a QGIS plugin adding a dock panel showing a magnification of the map canvas around a selected point. Map tools are still usable in the map canvas, and in the ZoomView as well.