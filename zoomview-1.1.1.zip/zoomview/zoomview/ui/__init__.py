from os.path import dirname

path = dirname(__file__)
